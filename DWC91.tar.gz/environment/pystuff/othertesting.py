print("File name is: " + __name__)
# def main():