class bcolors:
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKCYAN = '\033[96m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'
# print(f"{bcolors.WARNING}Warning: No active frommets remain. Continue?{bcolors.ENDC}")
print(f"{bcolors.HEADER}This is a ciphering program. Stay Awesome.{bcolors.ENDC}")


alphabet = "".join([chr(x + ord('a')) for x in range(26)]) 
# alpha_diode = {}
# for char in alphabet:
#     alpha_diode[char] = False
al_diode = [False]* len(alphabet)
# print(al_diode)
# print(" ".join(al_diode.values()))

key = 3

wrap = 0
for i in range(len(alphabet)):
    wrap += key
    if wrap >= len(alphabet):
        for val in al_diode:
            c = f"{bcolors.OKGREEN}T{bcolors.ENDC}" if val else f"{bcolors.FAIL}F{bcolors.ENDC}"
            print(c, end=" ")
        print()
        wrap %= 26
    al_diode[(i * key) % 26] = True
    
    # al_diode[chr(ord('a'))]

