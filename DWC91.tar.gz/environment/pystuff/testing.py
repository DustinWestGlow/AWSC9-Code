import othertesting

print("File name is: " + __name__)
# def main():
#     print("Hello, World!")

# if __name__ == "main":
#     main()