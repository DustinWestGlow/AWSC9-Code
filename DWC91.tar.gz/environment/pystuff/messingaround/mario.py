height = 5

for i in range(height):
    string = (" " * (height - i - 1)) + ("#" * (i + 1))
    print(string)